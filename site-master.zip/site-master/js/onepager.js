
jQuery(document).ready(function () {

    //page scroll
    jQuery('body').pageScroller({
        navigation: '#nav .onepage',
        sectionClass: 'chapter',
        scrollOffset: '-110'
    });

});

